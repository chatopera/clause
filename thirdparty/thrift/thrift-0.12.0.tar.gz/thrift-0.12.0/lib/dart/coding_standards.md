# Dart Coding Standards

### Please follow:
 * [Thrift General Coding Standards](/doc/coding_standards.md)
 * [Use dartfmt](https://www.dartlang.org/tools/dartfmt/) and follow the 
   [Dart Style Guide](https://www.dartlang.org/articles/style-guide/)
