## Python Coding Standards

Please follow:
 * [Thrift General Coding Standards](/doc/coding_standards.md)
 * Code Style for Python Code [PEP8](http://legacy.python.org/dev/peps/pep-0008/)

When in doubt - check with <http://www.pylint.org/> or online with <http://pep8online.com>.
